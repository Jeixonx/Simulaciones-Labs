function x2 = sigmoide(x)

    x2 = 1./(1 + exp(-x));

end